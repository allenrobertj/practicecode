package com.springboot.bmanagement.service;

import org.springframework.stereotype.Service;

import com.springboot.bmanagement.model.Book;
import com.springboot.bmanagement.repository.BookRepository;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {
    private final BookRepository repo;

    public BookService(BookRepository repo) {
        this.repo = repo;
    }

    public List<Book> findAll() {
        return repo.findAll();
    }

    public Optional<Book> findById(Long id) {
        return repo.findById(id);
    }

    public Book save(Book book) {
        return repo.save(book);
    }

    public Book update(Long id, Book book) {
        return repo.findById(id).map(existing -> {
            existing.setTitle(book.getTitle());
            existing.setAuthor(book.getAuthor());
            existing.setYearPublished(book.getYearPublished());
            return repo.save(existing);
        }).orElseThrow(() -> new RuntimeException("Book not found with id " + id));
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
